# src/__main__.py

import services

services.run_tomorrow()